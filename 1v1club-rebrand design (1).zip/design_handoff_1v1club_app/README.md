# Handoff: 1v1club — Peer-to-Peer Wagering App

## Overview
1v1club lets friends challenge each other to casual games (golf, tennis, chess, pool), stake real money into a shared pot, play, declare a winner, and get an instant payout. This handoff covers the full mobile app: dashboard, wager lifecycle (create → invite → join → live → declare → payout), dispute/review, plus profile, history, notifications, leaderboard/friends, trash-talk chat, and wallet/cash-out.

The design has **two complete themes**: light ("Split") and dark ("Voltage"), toggled in the dashboard header. Both must be supported.

## About the Design Files
The file in this bundle (`1v1club App.dc.html`) is a **design reference created in HTML** — a working prototype showing the intended look, flow, and interactions. **It is not production code to copy directly.** The `.dc.html` format is a self-contained prototype harness; ignore the harness and the `<script data-dc-script>` logic conventions.

Your task is to **recreate these designs in the target codebase's existing environment** (React, React Native, SwiftUI, Flutter, etc.), using its established components, navigation, and state patterns. If no environment exists yet, choose the most appropriate framework for a mobile-first product and implement there. The existing prototype is built around a single component with a `view` state string switching between screens — in a real app these become routed screens.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, and interactions are specified below and should be recreated faithfully. All measurements are in px at a 380×800 logical phone frame (iPhone-class). Use the codebase's existing UI primitives where they exist, matching these values.

---

## Design System / Tokens

### Logo / wordmark
- **Name:** `1v1club` (one word, lowercase). Set in Bricolage Grotesque 800, letter-spacing -0.03em.
- **Two-tone treatment:** `1v1` in `--ink`, `club` in `--you` (cobalt) — on dark surfaces use `#7d8cff` for the `club` segment for contrast.
- **Mark:** the split-coin — a circle divided by a diagonal seam, cobalt (`--you`) over coral (`--rival`) halves, with a center dot ring in `--ink`. Same construction at every size (favicon → app icon).

### Type families
- **Display / headings:** `Bricolage Grotesque` (weights 600/700/800). Used for greetings, screen titles, big numbers, pot amounts.
- **Body / UI:** `Hanken Grotesk` (400/500/600/700/800). Default for labels, list rows, buttons.
- **Mono / labels:** `JetBrains Mono` (400/600/700). Used for ALL-CAPS micro-labels, timestamps, status tags, monetary tickers. Letter-spacing 0.08–0.24em.

### Color tokens (CSS custom properties)
The app is themed with CSS variables. Two themes:

| Token | Light (Split) | Dark (Voltage) | Usage |
|---|---|---|---|
| `--bg` | `#f4f2ec` | `#0c0d12` | Screen background |
| `--surface` | `#ffffff` | `#15171e` | Cards, rows, inputs |
| `--border` | `#e8e6df` | `#23252e` | Hairlines, card borders |
| `--ink` | `#16171b` | `#f2f3f6` | Primary text |
| `--muted` | `#71727c` | `#80828e` | Secondary text, labels |
| `--you` | `#2f4bff` | `#5a6dff` | "You" identity (cobalt) |
| `--you-tint` | `#eceeff` | `#181d33` | "You" fill / tint backgrounds |
| `--rival` | `#ff4a30` | `#ff5a3c` | Opponent identity (coral) |
| `--rival-tint` | `#ffece8` | `#2e1a16` | Opponent fill / tint |
| `--win` | `#2f4bff` | `#7d8cff` | Positive/win text, accents |
| `--amber` | `#c8881f` | `#e0a23a` | "Declaring" status |
| `--amber-bg` | `#fbf0db` | `rgba(224,162,58,.14)` | Amber tag bg |
| `--await` | `#71727c` | `#80828e` | "Awaiting" status |
| `--await-bg` | `#eeede7` | `#1b1e27` | Await tag bg |
| `--glyph-bg` | `#f1f0ea` | `#1b1e27` | Icon tile / avatar fallback bg |
| `--cta-bg` | `#16171b` (ink) | `#5a6dff` (cobalt) | Primary button bg |
| `--cta-ink` | `#ffffff` | `#ffffff` | Primary button text |
| `--cta-shadow` | none | `0 10px 30px -6px rgba(90,109,255,.55)` | CTA glow (dark only) |
| `--pot-bg` | `#16171b` | `#f2f3f6` | Pot "coin" bg |
| `--pot-ink` | `#ffffff` | `#0c0d12` | Pot coin text |
| `--pot-shadow` | `0 5px 14px -3px rgba(0,0,0,.4)` | `0 0 24px -2px rgba(90,109,255,.55)` | Pot coin shadow/glow |
| `--toggle-track` | `#e8e6df` | `#23252e` | Theme-toggle track |
| `--bezel` | `#17181c` | `#08090c` | Phone bezel (prototype only) |

**Identity color rule:** "You" is always cobalt (`--you`), the opponent is always coral (`--rival`). This duotone drives the whole app — avatars, the diagonal matchup bar, win/loss bars, leaderboard ranks.

### Spacing & radii
- Screen horizontal padding: **20px**.
- Card radius: **16–20px**; list-row radius: **13–14px**; pill/tag radius: **5–9px**; icon tiles: **10–13px**.
- Standard gap between list items: **9px**; between sections: **22px** top margin on the section label.
- Section micro-labels: JetBrains Mono, 10px, 700, letter-spacing .16em, color `--muted`, ALL CAPS.

### Buttons
- **Primary CTA:** full-width, `--cta-bg` bg, `--cta-ink` text, radius 14px, padding 16px, Bricolage Grotesque 800/15px, plus `--cta-shadow`. In light theme it's ink-black; in dark it's glowing cobalt.
- **Disabled CTA:** `--surface` bg, `--muted` text, `1px solid --border`, no shadow, `cursor:default`.
- **Secondary text link:** Hanken 600/12px, color `--win`, centered.

### Signature component — the Matchup bar
A horizontal bar split by a **diagonal seam** with the pot as a centered circular "coin":
- Container: `position:relative; height:90–112px; border-radius:18px; overflow:hidden; border:1px solid --border`.
- Left panel (You): `position:absolute; left:0; width:58%; background:--you-tint;` clipped with `clip-path:polygon(0 0,100% 0,calc(100% - 30px) 100%,0 100%)`. Holds avatar (cobalt circle, white initial) + name + "PAID $X" in `--win`.
- Right panel (Rival): `position:absolute; right:0; left:42%; background:--rival-tint;` clipped with `clip-path:polygon(30px 0,100% 0,100% 100%,0 100%)`. Right-aligned, coral avatar, "PAID $X" in `--rival`.
- Pot coin: centered, `position:absolute; left:50%; top:50%; transform:translate(-50%,-50%)`, ~56–66px circle, `--pot-bg`/`--pot-ink`, `--pot-shadow`, 3px solid `--pot-border` ring. Shows pot amount (Bricolage 800) over "POT" (JetBrains Mono 7px).

---

## Screens / Views

All screens sit inside a 380×800 phone frame with a status bar (9:41 + signal/battery) at top. Each content area is a vertical flex column with 20px horizontal padding and its own scroll.

### 1. Dashboard (`view: dashboard`)
- **Purpose:** Home — see live wager, stats, pending wagers, start a new challenge.
- **Header row:** left = "MON · JUN 26" (mono micro-label) above "Evening, Marcus" (Bricolage 800/25px). Right = a cluster: **notification bell** (42px circle, `--surface`, unread count badge "3" in `--rival`) → **theme toggle** (segmented sun/moon, 28px tiles in a `--toggle-track` pill) → **avatar** "MB" (42px `--glyph-bg` circle with `--rival` unread dot). Bell opens Notifications; avatar opens Profile/History.
- **"// LIVE NOW"** mono label, then the **live wager card** (`--surface`, radius 18px): sport row (glyph + "GOLF · 9 HOLES" + "● LIVE" in `--win`), the **matchup bar** (height 90px), and the bet line "First to par. Loser buys dinner." Tapping opens Detail.
- **Stats strip:** 3-up row in one `--surface` card divided by `--border`: "7–2 RECORD", "$340 IN PLAY", "78% WIN RATE" (the % in `--win`).
- **"Your wagers"** (Bricolage 800/15px) with right-aligned tabs PENDING (active: `--ink` bg, `--bg` text, radius 7px) / HISTORY (muted, tappable → Profile/History).
- **Pending wager rows:** `--surface` rows, radius 13px, each with a 4px vertical gradient bar (`linear-gradient(--you 0 50%, --rival 50% 100%)`), a glyph tile, sport + status tag + "vs X · detail", and pot amount right-aligned. Chess row → "DECLARING" amber tag; Tennis row → "AWAITING" tag.
- **Primary CTA:** "+ New challenge" → Create.

### 2. Wager Detail (`view: detail`, data id: golf/chess/tennis)
- **Purpose:** Full view of one wager + declare/act.
- Header: back chevron (34px `--surface` tile) · "GOLF · 9 HOLES" mono · status pill (LIVE/DECLARING/AWAITING).
- Title (Bricolage 800/28px, 2 lines): "First to par, loser buys dinner."
- **Matchup bar** (height 112px) with "PAID $50" on each side.
- **Escrow card** (`--surface`, radius 18px): rows "Your stake $50.00 ✓", "Tyler's stake $50.00 ✓", "Platform fee (5%) −$5.00", divider, "Winner takes **$95.00**" (amount in `--win`, Bricolage 800/20px).
- **Date/place chips:** two `--surface` pills with calendar + pin icons ("Sat Jun 28", "Pebble Creek").
- **Trash-talk row:** `--surface` row → chat bubble glyph tile, "Trash talk" + last-message preview, unread badge "2" in `--rival`. Opens Chat.
- **Primary CTA:** "Declare the winner" → Declare. Below it, a lock icon + "Funds held securely until both confirm".

### 3. Create (`view: create`)
- **Purpose:** Configure a new wager.
- Title "Set the stakes."
- **SPORT** — 2×... actually a 4-up grid of chips (Golf/Tennis/Chess/Pool), each a glyph + label. Selected chip: `--you-tint` bg, `1.5px solid --you`, `--you` text.
- **STAKE — EACH PLAYER** — row of amount chips $10/$25/$50/$100, same selected styling.
- **Pot card:** "TOTAL POT $100.00" (left) and "WINNER TAKES $95.00 / after 5% fee" (right). Both recompute live from amount × 2 and minus 5%.
- **THE BET** — `--surface` row with the bet text + edit (pencil) icon.
- **OPPONENT** — selected "Invite by link" row (`--you-tint`, `--you` border, check).
- CTA: "Create & get invite link" → Invite.

### 4. Invite (`view: invite`)
- **Purpose:** Share link, wait for opponent.
- Centered check badge, "Challenge is live", subtitle "Golf · 9 holes · $100 pot · winner takes $95.00".
- **Matchup bar** with right side = "Pending / NOT JOINED" (await styling, dashed "?" avatar).
- **SHARE LINK** — `--surface` row showing "1v1club.gg/j/9F2K-A7" + Copy button (flips to "Copied ✓").
- Pulsing dot + "Waiting for your opponent to accept…" (dot uses `@keyframes wgpulse`).
- Buttons: "Preview: opponent joins" → Detail(live); "See the invite as your opponent →" → Join.

### 5. Join — opponent view (`view: join`)
- **Purpose:** What the invitee sees.
- Title "Marcus challenged you." + subtitle.
- **Matchup bar** with You(left)=Marcus PAID, right=You PAY (coral).
- Sport summary card with the bet + stake/pot/winner breakdown.
- CTA: "Accept & pay $50.00" → Detail(live). Secondary "Decline".

### 6. Declare (`view: declare`)
- **Purpose:** Pick the winner.
- Title "Who won?" + subtitle about both confirming / review.
- Two large tappable cards (You / Tyler J.), each avatar + name + "TAP TO PICK". Selected card: 2px solid identity color + tint bg, label → "WINNER ✓".
- Info card "Winner of the $100 pot takes $95.00".
- CTA "Confirm result" (disabled until a pick) → Payout. Below: underlined "We disagree on the result" → Dispute.

### 7. Payout (`view: payout`)
- **Purpose:** Resolution.
- Centered pot coin with glow halo, big "$95"/"$0", title "You won." / "Tyler won.", subtitle.
- **Matchup bar** with winner side full opacity, loser dimmed (.45). "WON $95" / "LOST".
- Payout-method card: card glyph + "Paid to your account / Visa •••• 4242 · instant" + amount in `--win`.
- CTA "Back to home" → Dashboard. Secondary "Rematch →" → Create.
- **Logic:** if pick === 'rival', You lost (amounts $0 / Tyler won); else You won. All payout copy/opacity flips accordingly.

### 8. Dispute / Review (`view: dispute`)
- Header "UNDER REVIEW". Amber warning triangle, "Results don't match", "You both claimed the win. The pot is frozen until it's sorted."
- Two cards: "You said I WON" (cobalt) / "Tyler said I WON" (coral).
- **HOW TO RESOLVE** — two rows: "Add evidence / Scorecard photo or witness" (→ Evidence) and "1v1club review / A mod decides within 24h".
- CTA "Submit to review" → History. Secondary "Actually, let me re-pick" → Declare.

### 9. Evidence Upload (`view: evidence`)
- Title "Show your proof." + subtitle referencing the $100 pot.
- **UPLOADS** — dashed drop zone (`+` in a `--you-tint` tile, "Add photo or file / Tap to attach · JPG, PNG, PDF"). Tapping adds an uploaded-file row ("scorecard-final.jpg / 1.4 MB · UPLOADED ✓", image glyph, × to remove).
- **NOTE TO REVIEWER · OPTIONAL** — `--surface` text block with a sample note.
- CTA: "Attach evidence first" (disabled) until a file is added → becomes "Submit to reviewer" → Dispute. Lock + "Evidence is shared only with the reviewer".

### 10. History / Profile (`view: history`)
- **Purpose:** Your record, wallet entry, settled wagers.
- Header "YOUR RECORD" + back to Dashboard.
- Identity row: 56px avatar "MB" + "Marcus Bell" (Bricolage 800/22px) + "@marcusb · JOINED 2025".
- 3-up stat cards: "7–2 RECORD", "+$240 NET · MONTH" (in `--win`), "W3 STREAK".
- **Wallet card** (uses `--cta-bg`/`--cta-ink`): card glyph + "WALLET BALANCE $418.50" + "Cash out" chip. Tapping → Wallet.
- **SETTLED** section label with right-aligned "🏆 LEADERBOARD" link (trophy icon, `--win`) → Leaderboard.
- Settled rows: 4px win/loss gradient bar (winner color on top), monogram glyph (G/P/C/T), "Golf · 18 holes / vs Tyler J. · Jun 21", amount + WON/LOST. Amount colored `--win` (won) or `--rival` (lost).

### 11. Notifications (`view: notifs`)
- Header "NOTIFICATIONS" + "Mark read".
- **NEW** rows (border `--you`, unread dot): avatar + message + timestamp. Tapping routes (dispute / accepted challenge → chess detail / incoming invite → join).
- **EARLIER** rows: dimmed, no border accent.

### 12. Leaderboard / Friends (`view: leaderboard`)
- Header "FRIENDS" + back to History + **user-plus icon** (→ Add Friend).
- "This month" title + segmented toggle "Net winnings" (active: `--ink` bg, `--bg` text) / "Win rate".
- **Podium:** 3 columns (Dev #2, You #1 center taller, Sam #3) — avatar + name + net, with pedestal blocks of decreasing height; your block uses `--you-tint`/`--you`.
- Ranked list rows: rank number, avatar, name + record, net (yours `--win`, negatives `--rival`). Your row highlighted (`--you-tint` + `--you` border).

### 13. Add Friend (`view: addfriend`)
- Header "ADD FRIENDS".
- Search input (`--surface`, magnifier icon, sample query "jordan" with a cobalt caret bar).
- **RESULTS** rows: avatar + name + "@handle · N mutual" + Add button. Add → "Requested" (per-row state; tapped row's button becomes muted/`--surface`/`cursor:default`, others stay actionable).
- **INVITE OFF-APP** — share-link row "1v1club.gg/i/marcusb" + Share button.

### 14. Wallet (`view: wallet`)
- Header "WALLET" + back to History.
- **Balance card** (`--cta-bg`/`--cta-ink`, radius 20px): "AVAILABLE BALANCE $418.50" (Bricolage 800/42px), divider, "$100 in escrow · +$240 this month".
- Two action tiles: "Cash out" (down arrow, → Cash Out) / "Add funds" (up arrow).
- **ACTIVITY** ledger rows: glyph (↓ won / ↑ out, won uses `--you-tint`/`--you`), title + sub, amount (`--win` for credits, `--ink` for debits). Sample: Won vs Tyler +$95, Stake escrowed −$50, Won vs Dev +$38, Cashed out −$200.

### 15. Cash Out (`view: cashout`)
- Header "CASH OUT" + back to Wallet.
- Centered "AMOUNT $418.50" (Bricolage 800/56px) + "Cash out full balance" link.
- Quick amounts $50 / $100 / All (All selected: `--you-tint`/`--you`).
- **TO** — destination card "Visa •••• 4242 / Instant · arrives in seconds".
- "Instant fee (1.5%) −$6.28".
- CTA "Cash out $412.22" → Wallet (confirmed).

---

## Interactions & Behavior
- **Navigation:** single `view` string drives which screen renders; transitions are instant (no page animation in the prototype — add your platform's standard push/modal transitions).
- **Theme toggle:** sun/moon in the dashboard header swaps the entire CSS-variable set; persists across the session. Default is **dark**.
- **Live recompute:** Create screen's pot/winner update from `amount × 2` and `pot × 0.95`.
- **Copy link:** writes to clipboard, button label flips to "Copied ✓".
- **Declare → outcome:** picking the rival makes You lose; picking yourself makes You win; Payout content derives from this.
- **Evidence CTA gating:** disabled until at least one upload exists.
- **Add-friend state:** per-handle "requested" flag; tapping Add flips only that row.
- **Pulsing/typing dots:** `@keyframes wgpulse { 0%,100%{transform:scale(1);opacity:1} 50%{transform:scale(1.5);opacity:.35} }`. Chat typing indicator staggers three dots by 0/.2/.4s.
- **Unread badges:** bell shows "3"; trash-talk row shows "2".

## State Management
Minimal session state (no backend in the prototype):
- `theme`: 'light' | 'dark'
- `view`: current screen key
- `id`: which wager is open in Detail ('golf' | 'chess' | 'tennis')
- `createSport`, `createAmount`: Create selections
- `declarePick`: 'you' | 'rival' | null
- `copied`, `uploaded`, `cashedOut`: one-shot UI flags
- `friendAdds`: map of handle → requested
In production, back these with real wager/user/wallet/chat data and routed screens.

## Interactions requiring backend (note for implementer)
Pot escrow + payout, identity/auth, invite link generation + accept, real-time chat, push notifications, dispute resolution/mod queue, KYC + cash-out rails (the $X.XX values and Visa •••• 4242 are placeholders).

## Assets
- **Icons:** all inline monoline SVGs (stroke-width 2, round caps/joins) drawn in the markup — golf flag, tennis ball, chess pawn, pool ball, bell, calendar, pin, chat bubble, card, lock, trophy, user-plus, magnifier, arrows, send. Recreate with your icon library (Lucide/SF Symbols/etc.) matching the monoline weight.
- **Sport glyphs:** custom SVGs (not emoji) — reuse across cards.
- **Avatars:** initial monograms on identity-colored circles; no image assets.
- **Fonts:** Bricolage Grotesque, Hanken Grotesk, JetBrains Mono (Google Fonts).
- A couple of emoji appear in trash-talk copy only (🏌️ 😏) — optional flavor.

## Files
- `1v1club App.dc.html` — the complete prototype (all 15 screens, both themes, all interactions). Open in a browser to click through. This is the source of truth for look + behavior.
